
let bola = document.createElement('div');
    bola.style.borderRadius = '50%';
    bola.style.border = "2px solid";
    bola.style.height = "100px";
    bola.style.width = "100px";
    bola.style.top = (window.innerHeight);
    bola.style.left = (window.innerWidth);
    bola.style.position = "absolute";
    bola.moveT;


document.body.appendChild(bola);
